const form = document.getElementById('purchase-form');
const button = document.getElementById('pay-button');
const message = document.getElementById('checkout-message');
const statusLink = document.getElementById('status-link');
async function paymentApi(action, body) {
    const apiBase = form.dataset.apiBase || 'api/payments.php';
    const endpoint = new URL(apiBase, window.location.href);
    endpoint.searchParams.set('action', action);
    const response = await fetch(endpoint.toString(), {
        method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': form.dataset.csrf},
        body: JSON.stringify({...body, action})
    });
    const raw = await response.text();
    let data;
    try {
        data = JSON.parse(raw);
    } catch (error) {
        throw new Error(`Payment API returned ${response.status} instead of JSON. Check: ${endpoint.toString()}`);
    }
    if (!response.ok || !data.success) throw new Error(data.message || 'Payment request could not be completed.');
    return data;
}
form.addEventListener('submit', async event => {
    event.preventDefault();
    button.disabled = true;
    message.textContent = 'Preparing your secure checkout…';
    let confirming = false;
    try {
        if (typeof Razorpay === 'undefined') throw new Error('Secure checkout could not load. Please refresh and try again.');
        const buyer = Object.fromEntries(new FormData(form));
        const order = await paymentApi('create', {...buyer, slug: form.dataset.slug});
        const statusBase = form.dataset.statusBase || 'payment-success.php';
        const statusUrl = `${statusBase}?token=${encodeURIComponent(order.token)}`;
        const libraryPages = {
            'digital-playbook-for-managers': 'product-2-library.php',
            'gen-z-work-toolkit': 'product-3-library.php'
        };
        const libraryPage = libraryPages[form.dataset.slug];
        const successUrl = form.dataset.successUrl || (libraryPage
            ? `${libraryPage}?token=${encodeURIComponent(order.token)}`
            : statusUrl);
        statusLink.href = statusUrl;
        statusLink.classList.remove('hidden');
        const checkout = new Razorpay({
            key: order.key_id, order_id: order.order_id, amount: order.amount, currency: order.currency,
            name: 'LearningBox', description: order.product_name,
            prefill: {name: buyer.name, email: buyer.email, contact: buyer.phone}, theme: {color: '#000976'},
            handler: async result => {
                confirming = true;
                button.disabled = true;
                message.textContent = 'Confirming your payment…';
                let paymentConfirmed = false;
                try {
                    const verified = await paymentApi('verify', {...result, token: order.token});
                    // Only open the protected library after the server confirms
                    // that the payment has been fully captured.
                    paymentConfirmed = verified.status === 'paid';
                    if (!paymentConfirmed) {
                        message.textContent = 'Payment received. We are waiting for final confirmation...';
                    }
                } catch (error) {
                    message.textContent = 'Confirmation is taking longer than expected. Opening your purchase status…';
                }
                window.location.assign(paymentConfirmed ? successUrl : statusUrl);
            },
            modal: {ondismiss: () => {
                if (!confirming) {
                    button.disabled = false;
                    message.textContent = 'Checkout closed. If money was debited, check your purchase status before trying again.';
                }
            }}
        });
        checkout.on('payment.failed', () => {
            message.textContent = 'Payment attempt failed. You can retry in checkout. If money was debited, check your purchase status first.';
        });
        checkout.open();
        message.textContent = 'Complete your payment in the secure checkout window.';
    } catch (error) {
        message.textContent = error.message || 'Unable to open checkout. Please try again.';
        button.disabled = false;
    }
});
