-- Import once through cPanel phpMyAdmin into the existing database.
CREATE TABLE IF NOT EXISTS products (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(180) NOT NULL,
 slug VARCHAR(180) NOT NULL UNIQUE,
 description TEXT NOT NULL,
 amount INT UNSIGNED NOT NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Product 1 is shown through products/product01/ and charged INR 1 there.
INSERT INTO products (name, slug, description, amount, active)
VALUES ('Relationship Health Diagnostic', 'relationship-health-diagnostic', 'Product 1 preview and verification payment.', 99900, 1)
ON DUPLICATE KEY UPDATE active = 1;

CREATE TABLE IF NOT EXISTS purchases (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 token CHAR(64) NOT NULL UNIQUE,
 product_id BIGINT UNSIGNED NOT NULL,
 product_name VARCHAR(180) NOT NULL,
 amount INT UNSIGNED NOT NULL,
 currency CHAR(3) NOT NULL DEFAULT 'INR',
 buyer_name VARCHAR(120) NOT NULL,
 buyer_email VARCHAR(254) NOT NULL,
 buyer_phone VARCHAR(25) NOT NULL,
 status VARCHAR(24) NOT NULL DEFAULT 'creating',
 razorpay_order_id VARCHAR(80) NULL UNIQUE,
 razorpay_payment_id VARCHAR(80) NULL UNIQUE,
 failure_reason VARCHAR(255) NULL,
 paid_at DATETIME NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX(status, created_at),
 FOREIGN KEY(product_id) REFERENCES products(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS payment_emails (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 purchase_id BIGINT UNSIGNED NOT NULL,
 recipient_type VARCHAR(10) NOT NULL,
 status VARCHAR(16) NOT NULL DEFAULT 'pending',
 attempts INT NOT NULL DEFAULT 0,
 next_attempt_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 sent_at DATETIME NULL,
 UNIQUE(purchase_id, recipient_type),
 FOREIGN KEY(purchase_id) REFERENCES purchases(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
